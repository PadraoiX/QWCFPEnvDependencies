/**
 * 
 */
package br.com.pix.qware.qwcfp.beans;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.codec.binary.Base64OutputStream;

/**
 * <h3>ATENÇÃO!</h3>
 * <p> Esta classe deixou de existir, pois foi criada uma classe DTO
 * que pode ser usada tanto no QWCFP View, quanto no WSProxy.</p>
 * 
 * <p>Este código pode ser apagado, quando estiverem seguros de que não 
 * precisa mais ser usado.</p>
 * 
 * @author Anderson
 * 
 * @see br.com.pix.qware.wsproxy.dto.wsdlDoc
 *
 */
public abstract class URIWsUtils extends AbstractBean {
	/**
	 * 
	 */
	private static final long serialVersionUID = -5810958736817766457L;

}
