package br.com.pix.qware.qwcfp.convert;

public interface SampleEntity {
	
	public Long getId();
}
