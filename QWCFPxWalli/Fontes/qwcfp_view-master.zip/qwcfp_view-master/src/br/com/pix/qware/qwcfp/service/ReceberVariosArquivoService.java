package br.com.pix.qware.qwcfp.service;

public class ReceberVariosArquivoService extends Service{

	/**
	 * 
	 */
	private static final long	serialVersionUID	= 1L;

	
	
}
