/**
 * Este pacote estuda por enquanto as classes do Alcides
 */
/**
 * @author youre.fernandez
 *
 */
package br.com.pix.qware.qwcfp.util;