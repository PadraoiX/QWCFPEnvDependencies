package br.com.pix.qware.qwcfp.util;

public interface ITreeNode {
	
	public String getHashId();
	public Object getContent();
	public Class<?> getClassType();

}
