/**
 * <h1>PROJETO IMPLEMENTANDO A ESPECIFICAO JPA</h1>
 */
/**
 * @author youre.fernandez
 *
 */
package br.com.pix.qware.qwcfp.service;

/**
 * <h3>Neste pacote encontra-se as classes Services, que sero as responsvel por criar
 *    as regras de negcio da aplicao, ele chama os mtodos das classes do pacote DAO
 *    para conectar com o banco</h3>
 */
