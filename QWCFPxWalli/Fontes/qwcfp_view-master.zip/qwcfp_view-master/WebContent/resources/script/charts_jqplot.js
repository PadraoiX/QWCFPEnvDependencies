		function skinPie() {      
			this.cfg.grid = {
	            drawBorder: false, 
	            drawGridlines: false,
	            background: '#ffffff',
	            shadow:false
	        }
			this.cfg.legend= {
			        show: true,
			        location: 's',
			        rendererOptions: {
		                numberRows: 1
		            },
			        placement: 'outsideGrid'
			        	
			    };

			 
			 	/*this.cfg.shadow = false;
			    this.cfg.title = '';
			    this.cfg.seriesColors = ['#FF4081', '#FB8C00', '#43A047', '#8E24AA'];
			    this.cfg.grid = {
			        background: '#ffffff',
			        borderColor: '#ffffff',
			        gridLineColor: '#F5F5F5',
			        shadow: false
			    };
			    this.cfg.axesDefaults = {
			        rendererOptions: {
			            textColor: '#666F77'
			        }
			    };
			    this.cfg.seriesDefaults = {
			        shadow: false,
			        lineWidth:1,
			        markerOptions: {
			            shadow: false,
			            size:7,
			            style:'circle'
			        }
			    }	*/
		  };
		  